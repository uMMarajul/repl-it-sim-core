# Walkthrough: Guided Journeys & Multi-Persona AI 🧠

Use this guide to understand the new "Context-Switched Agent" architecture.

## 1. The "Guided Journey" UI
We moved away from a static chat to a **Goal-Oriented Interface**.
- **Journey Menu**: 3-column chip grid (Set Goals, Improve Health, Test Events).
- **Dynamic Suggestions**: Chips change based on the selected journey.
- **Mode Switching**: Clicking a journey sends a `mode` signal ('goals', 'health', 'events') to the backend.

## 2. Multi-Persona Architecture (`api/prompts.py`)
Instead of one massive prompt, we now split logic into 3 personas. The backend dynamically selects the prompt based on the `mode` signal.

### 🐣 Goal Setter (Mode: 'goals')
- **Vibe**: Enthusiastic, Efficient.
- **Rules**: Celebrates ONCE. Focuses on getting `targetAmount` and `targetDate` ASAP.
- **Goal**: Open the config window in 2-3 turns.

### 💪 Health Optimizer (Mode: 'health')
- **Vibe**: Analytical, Direct.
- **Focus**: Efficiency. Suggests ISAs, Pensions, and high-interest debt repayment.

### ⚡ Stress Tester (Mode: 'events')
- **Vibe**: Cautious, Protective.
- **Focus**: Resilience. Tests "What-If" scenarios (Job Loss, Market Crash) and checks Emergency Funds.

## 3. Universal Custom Scenario Logic
We empowered the `custom_goal` template to handle ANY financial concept using a **Decision Tree**:

1.  **Standard Match**: If user asks for "House", use `buy_home` (Specific fields).
2.  **Universal Fallback**: If user asks for "Horse", "Inheritance", or "Student Loan":
    -   AI maps it to `custom_goal`.
    -   AI assigns `direction`:
        -   `save` (Horse)
        -   `income` (Inheritance)
        -   `debt` (Student Loan)
    -   Result: One template to rule them all.

## 5. UI Polish & Theme Consistency (Phase 6)
We refined the visual experience to be consistent and legible:

-   **Solid vs Gradients**: Switched from gradients to solid **Replit Orange** (`#ff6b35`) for chat bubbles and buttons to improve text legibility.
-   **Theme Unification**: Fixed "Dark Mode" regressions where the config dialog header and "Reopen Configuration" buttons appeared black.
-   **Visual Feedback**:
    -   Added "Thinking" dots animation (Clean white style).
    -   Polished hover states for chips and secondary buttons.

### Visual Evolution
**Before: Dark/Black Theme Issues**
````carousel
![Black Config Window](/C:/Users/harri/.gemini/antigravity/brain/fe84d989-dca0-40ea-baba-f8a3495c0c62/uploaded_image_1768224553269.png)
<!-- slide -->
![Dark Chat Bubbles](/C:/Users/harri/.gemini/antigravity/brain/fe84d989-dca0-40ea-baba-f8a3495c0c62/uploaded_image_1768224183324.png)
````
## Phase 7: Azure OpenAI Migration ☁️

### Overview
Migrated the agent backend to support **Azure OpenAI Enterprise** alongside standard OpenAI.
- **Dynamic Config**: Automatically detects `AZURE_OPENAI_API_KEY` to switch modes.
- **Robustness**: Enforced `temperature=0` for strict schema compliance.

### Bug Fix: The "Amnesia" Patch 🧠
Identified that server restarts were wiping the in-memory session store.
- **Fix 1 (Frontend)**: Persisted `sessionId` in `localStorage` to survive page refreshes.
- **Fix 2 (Backend)**: Implemented `sessions.json` persistence to survive server restarts.
- **Fix 3 (Logic)**: Simplified Scenario Schema to match conversational flow (e.g. `buy_home` now accepts just `amount` + `date`).

### Configuration
```env
AZURE_OPENAI_API_KEY=...
AZURE_OPENAI_ENDPOINT=https://instance.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o
```

**Now**: Unified Orange Theme with clean secondary elements.
