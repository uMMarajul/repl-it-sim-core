# AI Agent Orchestration for Financial Goals

## Research Phase
- [x] Explore current scenario/goal system architecture
- [x] Review scenario registry and metadata structure
- [x] Understand configuration transformers
- [x] Analyze user input/profile structure
- [x] Identify integration points for AI agent

## Planning Phase
- [x] Design AI agent architecture
- [x] Define agent capabilities and constraints
- [x] Plan API/LLM integration approach
- [x] Design goal recommendation logic
- [x] Plan custom goal generation workflow
- [x] Define input/output formats

## Implementation Planning
- [x] Create detailed implementation plan
- [x] Review and iterate with user
- [x] Finalize approach and tech stack

## Phase 1: Foundation (OpenAI + Profile Extraction)
- [x] Install OpenAI SDK
- [x] Create AI agent types and interfaces
- [x] Build LLM client abstraction layer
- [x] Create profile extraction prompt
- [x] Implement profile extraction service
- [x] Build basic chat UI component
- [x] Test profile extraction end-to-end

## Backend Transition ✅
- [x] Create Python FastAPI backend service
- [x] Set up API endpoints for chat
- [x] Secure API key in environment
- [x] Update frontend to use backend API
- [x] Convert to chat widget (not separate page)
- [x] Test end-to-end with backend
- [x] Fix model compatibility (GPT-5 Nano)
- [x] Optimize response length

## AI Intent Detection & Config Integration ✅
- [x] Add intent detection to backend
- [x] Detect existing scenarios (BUY_HOME, EMERGENCY_FUND, etc.)
- [x] Extract parameters from conversation
- [x] Update frontend to trigger config windows
- [x] Pre-fill parameters from chat context
- [x] Implement rule-based intent detection (deterministic)
- [x] Professional financial planner conversational tone
- [x] Optimize defaults for beginners (assume rates, inflation)
- [x] User browser testing (Manual confirmation)

## Bidirectional AI-Simulation Integration
- [x] Phase 1: Context Passing ✅
  - [x] Update API models (ChatRequest, ChatResponse with context)
  - [x] Frontend: Extract and send simulation state
  - [x] Backend: Parse context in AI prompt
  - [x] Test context-aware responses
- [x] Phase 2: Action System ✅
  - [x] Define action types (CREATE, MODIFY, ACTIVATE, etc.)
  - [x] Backend: Generate scenario actions
  - [x] Frontend: Action executor (OPEN_CONFIG working)
## Phase 3: Financial Coaching (Bidirectional)
- [x] Create `financial_knowledge.json` (UK Rules: ISA, Pension, Tax)
- [x] Update System Prompt with "Coach" persona & Knowledge
- [x] Implement Compliance Guardrails (Disclaimer footer)
- [ ] Add Contextual Advice Logic (Age/Income based tips)
- [ ] Test Educational Queries ("What is an ISA?")

## Phase 2: Recommendation Engine
- [x] Expand rules engine with more scenarios
- [x] Create scenario recommendation prompts
- [x] Build hybrid recommender (rules + AI)
- [x] Fix simplifiedTemplates.ts duplicates and syntax
- [ ] Add explanation generation
- [ ] Test recommendations with sample profiles

## Phase 3: Custom Scenario Generation
- [x] Add `custom_goal` to Registry & Templates
- [x] Add generic fields (Name, Amount, Date) to `custom_goal` template
- [x] Add `custom_goal` to `scenario_patterns.json`
- [x] Update Prompt and Mapping to handle dynamic names
- [x] Add intelligent parameter suggestion (Direction & Frequency)
- [x] Test with edge cases

## Phase 4b: Universal Custom Scenarios (Expansion)
- [x] Update `custom_goal` template with Income, Debt, Transfers
- [x] Implement `ONE_OFF_INFLOW` and `RECURRING_INCOME` logic
- [x] Implement `NEW_DEBT` and `STUDENT_LOAN` logic
- [x] Implement `WITHDRAWAL` logic
- [x] Update Registry with all archetypes
- [x] Test new types
- [x] Fix ID Duplicate Bug (Added unique suffix)
- [x] Fix Withdrawal Source Logic (Added account picker)
- [x] Fix Connection Error on Date Input (Missing `dateparser` dependency)
- [x] Refine Scenario Explorer to show only active scenarios (Chat-first UX)
- [x] Update Config Window Title to use dynamic goal name (e.g. "Buying a horse")

## Phase 5: Guided Journeys & Archetype Logic
- [x] Implement "Journey Menu" in Chat UI (Goals, Health, Events)
- [x] Implement "Dynamic Suggestion Chips" based on selected Journey
- [x] Update System Prompt with "Coach Personas" (Setter, Optimizer, Tester)
- [x] Implement "Schema vs Archetype" decision tree in AI logic
- [x] Refactor into "Dynamic Prompts" (Split monolithic prompt into 3 files)
- [x] Update API to accept `mode` parameter from Frontend
- [x] Expand `custom_goal` to generic `custom_scenario` (logic added to prompts)
- [x] Test the "Unforeseen Events" flow

## Phase 6: UI Polish & UX Refinements
- [x] Add message entry animations (fade-in/slide-up)
- [x] Polish "Typing" indicator (animated dots)
- [x] Enhance Chip/Button hover states & transitions
- [x] Style custom scrollbars
- [x] Review Input field styling (focus rings, send button)

## Phase 7: Plan Visualizer (Chat Charts)
- [x] Create `ChatChart.tsx` component (Micro-chart)
- [x] Connect `ChatAssistant` to `useSimulation` hook
- [x] Implement "Snapshot" logic for message history
- [x] Render charts in chat bubbles for `OPEN_CONFIG` or `SAVE_CONFIG` actions

## Phase 8: Final UI Polish & Theme Unification
- [x] Update Chat Bubbles to solid Orange (Legibility)
- [x] Update Dialog Headers to Orange (Theme Consistency)
- [x] Fix "Reopen Configuration" button style
- [x] Enhance initial welcome message

