- [X] Consider replatforming onto Next?
- [X] Have a change request log
- [X] Want to switch out of Lovable
- [X] Previous dev changed the scoring mech
- [X] Could use the GPT into AI SDK?



- [ ] OG image and favicon system
- [ ] Other general site metadata
- [ ] Rate limiting, enabling / disabling AI chat features remotely

- [X] Change the layout in app(app) and app layout to be mobile responsive
- [ ] Set up prod db in supabase and move the links over


- [ ] Make sure the db schemas match up the previous one
- [ ] Plug in DB
- [ ] Set up auth carry over from anonymous

- [ ] Route protection, what requires auth etc

- [ ] Stop submit on navigate to last step
- [ ] Allow country to be focused by tab

- [ ] Refactor the balance accounts spec to be more flexible; but for now it looks good
- [ ] Add currencyinput type that allows for number £ input better
- [ ] Add better type validation on the frontend


- [X] Scoring & success page
- [ ] AWS updates and move over domains to Vercel
- [ ] Migrate users in journey
- [ ] Psychographic test question 2
- [ ] Add partner income to questionnaire
- [ ] Add notion to AWS domain
- [ ] Start on Google auto generating of analysis sheets

